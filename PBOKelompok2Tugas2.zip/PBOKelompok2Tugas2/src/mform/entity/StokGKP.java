/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mform.entity;

/**
 *
 * @author: Kelompok 2
 * 1. Alvin Jeremy Naiborhu
 * 2. Fstih Mudzaky
 * 3. Yedija Lewi Suryadi
 * 4. Zahra Mufidah
 */
public class StokGKP {
    private double stokPabrikGula;
    private double stokPedagang;
    private double stokPetani;
    
    public StokGKP(){
    }

    public double getStokPabrikGula() {
        return stokPabrikGula;
    }

    public void setStokPabrikGula(double stokPabrikGula) {
        this.stokPabrikGula = stokPabrikGula;
    }

    public double getStokPedagang() {
        return stokPedagang;
    }

    public void setStokPedagang(double stokPedagang) {
        this.stokPedagang = stokPedagang;
    }

    public double getStokPetani() {
        return stokPetani;
    }

    public void setStokPetani(double stokPetani) {
        this.stokPetani = stokPetani;
    }
           
}
